# www.groupecamerounada.com

Site du Groupe Camerounada et journal « Actualités ».

- `site/` : pages statiques du site du groupe.
- `contenu/actualites/` : un fichier Markdown par article (`AAAA-MM-JJ-slug.md`).
- `build.py` : construit `public/` (articles, page Actualités, sitemap, RSS, robots). Sans dépendance.

Cloudflare Pages : commande de build `python3 build.py`, dossier de sortie `public`.
Chaque push sur `main` republie le site.
