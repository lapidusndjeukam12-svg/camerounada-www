#!/usr/bin/env python3
"""Construit www.groupecamerounada.com + le journal « Actualités ».

Aucune dépendance : python3 build.py  ->  dossier public/
Articles : contenu/actualites/AAAA-MM-JJ-slug.md (en-tête « clé: valeur », puis corps en Markdown simple).
Champs : titre, description, date (AAAA-MM-JJ), categorie, image (facultatif), sources (liste « - Titre | URL »).
"""
import os, re, shutil, html, json, datetime

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC, OUT, ART = (os.path.join(ROOT, d) for d in ("site", "public", "contenu/actualites"))
BASE = "https://www.groupecamerounada.com"
MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
        "septembre", "octobre", "novembre", "décembre"]
CATS = {"canada": "Canada", "entree-express": "Entrée express", "etudes": "Études",
        "travail": "Travail", "visiteur": "Visa visiteur", "europe": "Europe",
        "conseils": "Conseils", "camerounada": "Camerounada"}


def date_fr(d):
    return f"{d.day} {MOIS[d.month - 1]} {d.year}"


def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<!\*)\*(?!\s)(.+?)(?<!\s)\*(?!\*)", r"<em>\1</em>", t)

    def lien(m):
        txt, url = m.group(1), m.group(2)
        ext = url.startswith("http") and "groupecamerounada.com" not in url
        rel = ' target="_blank" rel="noopener"' if ext else ""
        return f'<a href="{url}"{rel}>{txt}</a>'
    return re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", lien, t)


def markdown(md):
    out, liste, para = [], None, []

    def flush():
        nonlocal liste, para
        if para:
            out.append("<p>" + inline(" ".join(para)) + "</p>")
            para = []
        if liste:
            tag = liste[0]
            out.append(f"<{tag}>" + "".join(f"<li>{inline(i)}</li>" for i in liste[1]) + f"</{tag}>")
            liste = None

    for ligne in md.splitlines():
        s = ligne.strip()
        if not s:
            flush(); continue
        m = re.match(r"^(#{2,3})\s+(.*)", s)
        if m:
            flush()
            n = len(m.group(1))
            ident = re.sub(r"[^a-z0-9]+", "-", strip_accents(m.group(2).lower())).strip("-")
            out.append(f'<h{n} id="{ident}">{inline(m.group(2))}</h{n}>'); continue
        if s.startswith("> "):
            flush(); out.append('<aside class="note-art">' + inline(s[2:]) + "</aside>"); continue
        m = re.match(r"^(-|\d+\.)\s+(.*)", s)
        if m:
            if para:
                out.append("<p>" + inline(" ".join(para)) + "</p>"); para = []
            tag = "ul" if m.group(1) == "-" else "ol"
            if not liste or liste[0] != tag:
                flush(); liste = (tag, [])
            liste[1].append(m.group(2)); continue
        if liste:
            flush()
        para.append(s)
    flush()
    return "\n".join(out)


def strip_accents(s):
    tr = str.maketrans("àâäéèêëîïôöùûüçœæ", "aaaeeeeiioouuucoa")
    return s.translate(tr)


def lire_article(chemin):
    brut = open(chemin, encoding="utf-8").read()
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", brut, re.S)
    if not m:
        raise SystemExit(f"En-tête manquant : {chemin}")
    meta, corps = {}, m.group(2)
    cle = None
    for l in m.group(1).splitlines():
        if re.match(r"^\s+-\s", l) and cle:
            meta.setdefault(cle, []).append(l.strip()[2:].strip())
        elif ":" in l:
            cle, v = l.split(":", 1)
            cle = cle.strip(); v = v.strip()
            meta[cle] = v if v else []
    nom = os.path.basename(chemin)[:-3]
    d = datetime.date.fromisoformat(meta["date"])
    slug = meta.get("slug") or re.sub(r"^\d{4}-\d{2}-\d{2}-", "", nom)
    for champ in ("titre", "description"):
        if not meta.get(champ):
            raise SystemExit(f"Champ « {champ} » manquant : {chemin}")
    return {
        "titre": meta["titre"], "description": meta["description"], "date": d,
        "categorie": meta.get("categorie", "canada"), "image": meta.get("image", ""),
        "sources": meta.get("sources", []) if isinstance(meta.get("sources"), list) else [],
        "slug": slug, "corps": corps, "brouillon": meta.get("brouillon", "") == "oui",
        "url": f"{BASE}/actualites/{slug}/",
        "mots": len(re.findall(r"\w+", corps)),
    }


def gabarit_pages():
    """Récupère en-tête, pied de page et scripts de la page « Qui sommes-nous »."""
    p = open(os.path.join(SRC, "a-propos/index.html"), encoding="utf-8").read()
    head_assets = re.search(r'(<link rel="icon".*?<link rel="stylesheet"[^>]*>)', p, re.S).group(1)
    ticker = re.search(r'(<div class="ticker".*?</div>)', p, re.S).group(1)
    header = re.search(r"(<header class=\"top\">.*?</header>)", p, re.S).group(1)
    nav = ('<nav class="nav" aria-label="Navigation"><a href="/">Le groupe</a>'
           '<a href="/actualites/">Actualités</a><a href="https://travel.groupecamerounada.com/">Travel</a>'
           '<a href="/a-propos/">Qui sommes-nous</a></nav>')
    header = re.sub(r'<nav class="nav".*?</nav>', nav, header, flags=re.S)
    header = header.replace('href="#contact">Rendez-vous', 'href="https://wa.me/237656668200">Rendez-vous')
    footer = re.search(r"(<footer class=\"foot\">.*?</footer>\s*<a class=\"wa\".*?</a>)", p, re.S).group(1)
    scripts = re.search(r'(<script src="/assets/m\.js.*?</script>.*?</script>)', p, re.S).group(1)
    return head_assets, ticker, header, footer, scripts


def page(titre, desc, url, corps, extra_head=""):
    head_assets, ticker, header, footer, scripts = G
    t, d = html.escape(titre), html.escape(desc)
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{t}</title>
<meta name="description" content="{d}">
<meta name="theme-color" content="#013E43">
<meta property="og:title" content="{t}"><meta property="og:description" content="{d}"><meta property="og:url" content="{url}"><meta property="og:site_name" content="Groupe Camerounada"><meta property="og:locale" content="fr_FR">
{head_assets}
<link rel="stylesheet" href="/assets/blog.css?v={VERSION}">
<link rel="canonical" href="{url}"><meta name="robots" content="index,follow,max-image-preview:large">
<link rel="alternate" type="application/rss+xml" title="Actualités Camerounada" href="{BASE}/actualites/rss.xml">
{extra_head}</head>
<body>
{ticker}
{header}
<main>
{corps}
</main>
{footer}
{scripts}
</body>
</html>
"""


def carte(a):
    cat = CATS.get(a["categorie"], a["categorie"].capitalize())
    return (f'<article class="carte"><a href="/actualites/{a["slug"]}/">'
            f'<span class="cat">{html.escape(cat)}</span>'
            f'<h3>{html.escape(a["titre"])}</h3><p>{html.escape(a["description"])}</p>'
            f'<time datetime="{a["date"].isoformat()}">{date_fr(a["date"])}</time></a></article>')


def cta():
    return ('<section class="cta-art"><h2>Votre projet mérite une étude sérieuse</h2>'
            '<p>Nos conseillers étudient votre profil à Douala (Ndogbong) et à Yaoundé (Shell Nsimeyong). '
            'Écrivez-nous ou passez à l\'agence.</p>'
            '<div class="cta"><a class="btn dark" href="https://wa.me/237656668200">WhatsApp 656 66 82 00</a>'
            '<a class="btn line" href="https://travel.groupecamerounada.com/">Nos procédures</a></div></section>')


def construire():
    global G, VERSION
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    shutil.copytree(SRC, OUT)
    VERSION = datetime.datetime.now(datetime.timezone.utc).strftime("%y%m%d%H%M")
    G = gabarit_pages()
    shutil.copy(os.path.join(ROOT, "blog.css"), os.path.join(OUT, "assets/blog.css"))

    articles = []
    if os.path.isdir(ART):
        for f in sorted(os.listdir(ART)):
            if f.endswith(".md"):
                a = lire_article(os.path.join(ART, f))
                if not a["brouillon"] and a["date"] <= datetime.date.today() + datetime.timedelta(days=1):
                    articles.append(a)
    articles.sort(key=lambda a: (a["date"], a["slug"]), reverse=True)

    # Pages d'articles
    for i, a in enumerate(articles):
        cat = CATS.get(a["categorie"], a["categorie"].capitalize())
        sources = ""
        if a["sources"]:
            items = []
            for s in a["sources"]:
                titre, _, url = s.partition("|")
                items.append(f'<li><a href="{url.strip()}" target="_blank" rel="noopener">{html.escape(titre.strip())}</a></li>')
            sources = '<section class="sources"><h2>Sources officielles</h2><ul>' + "".join(items) + "</ul></section>"
        autres = [x for x in articles if x is not a][:3]
        suite = ('<section class="suite"><h2>À lire aussi</h2><div class="grille">'
                 + "".join(carte(x) for x in autres) + "</div></section>") if autres else ""
        minutes = max(1, round(a["mots"] / 200))
        ld = {
            "@context": "https://schema.org", "@type": "NewsArticle",
            "headline": a["titre"][:110], "description": a["description"],
            "datePublished": a["date"].isoformat(), "dateModified": a["date"].isoformat(),
            "inLanguage": "fr", "mainEntityOfPage": a["url"],
            "author": {"@type": "Organization", "name": "Rédaction Camerounada", "url": BASE + "/a-propos/"},
            "publisher": {"@type": "Organization", "name": "Groupe Camerounada",
                          "logo": {"@type": "ImageObject", "url": BASE + "/assets/icon-192.png"}},
        }
        fil = {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Accueil", "item": BASE + "/"},
            {"@type": "ListItem", "position": 2, "name": "Actualités", "item": BASE + "/actualites/"},
            {"@type": "ListItem", "position": 3, "name": a["titre"], "item": a["url"]}]}
        extra = ('<meta property="og:type" content="article">'
                 f'<meta property="article:published_time" content="{a["date"].isoformat()}">'
                 f'<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script>'
                 f'<script type="application/ld+json">{json.dumps(fil, ensure_ascii=False)}</script>\n')
        corps = (f'<article class="art"><div class="w etroit">'
                 f'<nav class="fil" aria-label="Fil d\'Ariane"><a href="/">Accueil</a> › <a href="/actualites/">Actualités</a> › <span>{html.escape(cat)}</span></nav>'
                 f'<span class="cat">{html.escape(cat)}</span><h1>{html.escape(a["titre"])}</h1>'
                 f'<p class="chapo">{html.escape(a["description"])}</p>'
                 f'<p class="meta">Rédaction Camerounada · <time datetime="{a["date"].isoformat()}">{date_fr(a["date"])}</time> · {minutes} min de lecture</p>'
                 f'<div class="prose">{markdown(a["corps"])}</div>'
                 f'{sources}'
                 '<p class="avert">Camerounada est soumise à une obligation de moyens : la décision finale appartient exclusivement aux autorités compétentes. '
                 'Aucune promesse de visa, de délai ou de résultat. Les règles changent : vérifiez toujours sur le site officiel avant toute démarche.</p>'
                 f'{cta()}{suite}</div></article>')
        d = os.path.join(OUT, "actualites", a["slug"])
        os.makedirs(d, exist_ok=True)
        open(os.path.join(d, "index.html"), "w", encoding="utf-8").write(
            page(f'{a["titre"]} · Camerounada', a["description"], a["url"], corps, extra))

    # Page d'accueil du journal
    une = articles[0] if articles else None
    tete = ""
    if une:
        tete = (f'<a class="une" href="/actualites/{une["slug"]}/"><span class="cat">À la une · {html.escape(CATS.get(une["categorie"], une["categorie"]))}</span>'
                f'<h2>{html.escape(une["titre"])}</h2><p>{html.escape(une["description"])}</p>'
                f'<time datetime="{une["date"].isoformat()}">{date_fr(une["date"])}</time></a>')
    reste = "".join(carte(a) for a in articles[1:])
    corps = ('<section class="hero-blog"><div class="w"><span class="pill">Le journal Camerounada</span>'
             '<h1>Actualités de l\'immigration, <em>vérifiées chaque jour.</em></h1>'
             '<p class="lead">Entrée express, études, travail, visas : ce qui change, ce que cela veut dire pour vous, et les sources officielles pour le vérifier.</p></div></section>'
             f'<section class="sec liste"><div class="w">{tete}<div class="grille">{reste}</div>'
             + ("" if articles else "<p>Premiers articles très bientôt.</p>") + "</div></section>")
    ld = {"@context": "https://schema.org", "@type": "Blog", "name": "Actualités Camerounada",
          "url": BASE + "/actualites/", "inLanguage": "fr",
          "blogPost": [{"@type": "BlogPosting", "headline": a["titre"], "url": a["url"],
                        "datePublished": a["date"].isoformat()} for a in articles[:20]]}
    os.makedirs(os.path.join(OUT, "actualites"), exist_ok=True)
    open(os.path.join(OUT, "actualites/index.html"), "w", encoding="utf-8").write(page(
        "Actualités immigration Canada et procédures · Camerounada",
        "Le journal Camerounada : actualité de l'immigration au Canada et en Europe, Entrée express, études, travail et visas, expliquée simplement depuis Douala et Yaoundé.",
        BASE + "/actualites/", corps,
        f'<script type="application/ld+json">{json.dumps(ld, ensure_ascii=False)}</script>\n'))

    # Lien « Actualités » dans les pages existantes
    for racine, _, fichiers in os.walk(OUT):
        if os.path.relpath(racine, OUT).startswith("actualites"):
            continue
        for f in fichiers:
            if f.endswith(".html"):
                p = os.path.join(racine, f)
                h = open(p, encoding="utf-8").read()
                if "/actualites/" not in h:
                    h = re.sub(r'(<nav class="nav"[^>]*>)', r'\1<a href="/actualites/">Actualités</a>', h, count=1)
                    h = h.replace('<nav aria-label="Le groupe">', '<nav aria-label="Le groupe"><a href="https://www.groupecamerounada.com/actualites/">Actualités</a>', 1)
                    open(p, "w", encoding="utf-8").write(h)

    # Sitemap, RSS, robots
    today = datetime.date.today().isoformat()
    derniere = articles[0]["date"].isoformat() if articles else today
    urls = [(BASE + "/", derniere, "daily"), (BASE + "/actualites/", derniere, "daily"),
            (BASE + "/a-propos/", today, "monthly"), (BASE + "/mentions-legales/", today, "yearly")]
    urls += [(a["url"], a["date"].isoformat(), "monthly") for a in articles]
    sm = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    sm += [f"<url><loc>{u}</loc><lastmod>{d}</lastmod><changefreq>{c}</changefreq></url>" for u, d, c in urls]
    sm.append("</urlset>")
    open(os.path.join(OUT, "sitemap.xml"), "w").write("\n".join(sm) + "\n")

    def rfc(d):
        return datetime.datetime(d.year, d.month, d.day, 8, 0, tzinfo=datetime.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    items = "".join(
        f"<item><title>{html.escape(a['titre'])}</title><link>{a['url']}</link><guid>{a['url']}</guid>"
        f"<pubDate>{rfc(a['date'])}</pubDate><description>{html.escape(a['description'])}</description></item>"
        for a in articles[:30])
    open(os.path.join(OUT, "actualites/rss.xml"), "w", encoding="utf-8").write(
        '<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel>'
        f"<title>Actualités Camerounada</title><link>{BASE}/actualites/</link>"
        "<description>Actualité de l'immigration expliquée par Camerounada</description><language>fr</language>"
        f"{items}</channel></rss>\n")
    open(os.path.join(OUT, "robots.txt"), "w").write(f"User-agent: *\nAllow: /\nSitemap: {BASE}/sitemap.xml\n")
    print(f"OK : {len(articles)} article(s) -> {OUT}")


if __name__ == "__main__":
    construire()
